#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 23 10:11:40 2021

@author: ketansahu
"""

from __future__ import print_function

import base64
import json
import boto3
from datetime import datetime


import pandas as pd


s3_client = boto3.client('s3')

# # Converting datetime object to string
# dateTimeObj = datetime.now()

# #format the string
# timestampStr = dateTimeObj.strftime("%d-%b-%Y-%H%M%S")

# this is the list for the records
kinesisRecords = []

def lambda_handler(event, context):
    for record in event['Records']:
        # Kinesis data is base64 encoded so decode here
        payload = base64.b64decode(record['kinesis']['data'])
        # Decoding the bytes to string
        payload = payload.decode("UTF-8")
        print ('payload is', payload)
        # append each record to a list
        kinesisRecords.append(payload)
        
    #print('kinesisRecords is', kinesisRecords)
   
    # make a string out of the list. Backslash n for new line in the s3 file
    metadata_string = '\n'.join(kinesisRecords)
    print('metadata_string is ',metadata_string )

    
    # generate the name for the file with the timestamp
    mykey = 'Data_Stream' + '.json'

    #put the file into the s3 bucket
    response = s3_client.put_object(Body=metadata_string, Bucket='bestsellerucket', Key= mykey)
    return 'Successfully processed {} records.'.format(len(event['Records']))
