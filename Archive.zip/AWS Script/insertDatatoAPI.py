#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 23 10:10:34 2021

@author: ketansahu
"""

import json
import boto3
import pandas as pd

def lambda_handler(event, context):

    method = event['context']['http-method']
    print ("method IS", method)
    meta_record = event['body-json']
    print('meta_record',meta_record)
    #print('type of meta_record',type(meta_record))
    
    meta_record = {k: v for k, v in meta_record.items() if v is not None}
    #dict to json
    meta_data = json.dumps(meta_record)
    print('meta_data',meta_data)

    client_meta_data = boto3.client('kinesis',region_name='us-east-1', endpoint_url='https://kinesis.us-east-1.amazonaws.com/')
    response = client_meta_data.put_record(
        StreamName='API_kinesis',
        Data= meta_data,
        PartitionKey='string'
    )

    return {
        'statusCode': 200,
        'body': json.dumps(meta_record)
    }