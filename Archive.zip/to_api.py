#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 21 20:53:39 2021

@author: ketansahu
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import pandas as pd
import requests
import time
import json



def parse(path):
    g = open(path, 'rb')
    for l in g:
        yield eval(l)
        
        
        
def getDF(path):
    i = 0
    df = {}
    for d in parse(path):
        df[i] = d
        i += 1
    data = pd.DataFrame.from_dict(df, orient='index')
    return data




def sample_function():

    myURL = "https://ererxuqi0f.execute-api.us-east-1.amazonaws.com/Data_Import_Stage/import-data"
    path = '/Users/ketansahu/Documents/DataEngineeringProject/BestSellerProject/inputfile/data.json'   

    meta_data = getDF(path)
    #print(meta_data)
    #Python dict to JSON   
    for i in meta_data.index:
        try:
            # convert the row to json
            export = meta_data.loc[i].to_json()

            # send it to the api
            response = requests.post(myURL, data=export)

            # print the returncode
            print(export)
            print(response)
        except:
            print(meta_data.loc[i])

if __name__ == "__main__":
    sample_function()


