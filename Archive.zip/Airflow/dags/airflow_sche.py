try:

    from datetime import timedelta
    from airflow import DAG
    from airflow.operators.python_operator import PythonOperator
    from datetime import datetime
    import pandas as pd
    import json
    import requests
#    import insert_data_to_api as df

    

    print("All Dag modules are ok ......")
except Exception as e:
    print("Error  {} ".format(e))



def sample_function():

    myURL = "https://ererxuqi0f.execute-api.us-east-1.amazonaws.com/Data_Import_Stage/import-data"
    
      # Read the testfile, json is converted to csv locally, by merging meta nad review data
    data = pd.read_csv('data.csv', sep=',')  
    for i in data.index:
        # print(i)
        try:
            # convert the row to json
            export = data.loc[i].to_json()

            # send it to the api
            response = requests.post(myURL, data=export)

            # print the returncode
            print(export)
            print(response)
        except:
            print(data.loc[i])

if __name__ == "__main__":
    sample_function()





with DAG(
        dag_id="first_dag",
        schedule_interval= '0 0-23/8 * * *',
        default_args={
            "owner": "airflow",
            "retries": 1,
            "retry_delay": timedelta(minutes=5),
            "start_date": datetime(2021, 4, 4),
        },
        catchup=False) as f:


    first_function_execute = PythonOperator(
        task_id="first_function_execute",
        python_callable=sample_function
    )


first_function_execute 

